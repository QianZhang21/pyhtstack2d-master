#!/bin/bash -x
for file in `ls $1`
do
    if [ ! -d $file ]; then
        continue
    fi
    cd $file
    if [ -d band ] && [ -f band/DOSCAR ];then
          cd band
          echo -e 211 | vaspkit >/dev/null 2>&1
          if [ -f BAND.dat ]; then
          rm REFORMATTED* DOSCAR EIGENVAL runlog
          else
          echo $file
          fi 
          cd ..
    fi
    cd ..
done
