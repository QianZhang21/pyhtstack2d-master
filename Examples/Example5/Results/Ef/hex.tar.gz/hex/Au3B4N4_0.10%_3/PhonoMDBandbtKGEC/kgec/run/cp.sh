#!/bin/sh
cpdir="../../../../../Sandwich_cal/bilayer_hex/Au3B4N4_0.10%_3/AA/cord1/opt/MD3/run"

for dir in `ls $1`
do
if [ -d $dir ];then
cp $cpdir/$dir/*out $dir/
cp $cpdir/$dir/*dat $dir/
fi
done
