#!/usr/bin/env python

from ase.io import read
import shutil

total_steps = 10000  # 假设总步数为10000
start = max(0, total_steps - 5000)
selected_indices = list(range(start, total_steps + 1, 500))
scfin = "scf.in"

for idx in selected_indices:
    folder = f"run/{idx}"
    shutil.copyfile(scfin, f"{folder}/scf.in")

    poscar_path = f"{folder}/POSCAR"

    # 读取POSCAR结构
    atoms = read(poscar_path, format='vasp')

    # 获取晶格、原子信息（保留分数坐标）
    cell = atoms.get_cell()
    symbols = atoms.get_chemical_symbols()
    unique_symbols = sorted(set(symbols), key=symbols.index)
    scaled_positions = atoms.get_scaled_positions()  # 分数坐标

    with open(f"{folder}/scf.in", "a+") as f:

        # 原子坐标（分数坐标）
        f.write("\nATOMIC_POSITIONS {crystal}\n")
        for s, pos in zip(symbols, scaled_positions):
            f.write(f"{s} {pos[0]:.8f} {pos[1]:.8f} {pos[2]:.8f}\n")

        # 晶胞参数
        f.write("\nCELL_PARAMETERS {angstrom}\n")
        for vec in cell:
            f.write(f"{vec[0]:.8f} {vec[1]:.8f} {vec[2]:.8f}\n")
