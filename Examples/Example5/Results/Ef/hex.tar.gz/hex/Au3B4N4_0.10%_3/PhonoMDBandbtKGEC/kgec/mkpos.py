#!/usr/bin/env python

from pymatgen.io.vasp.outputs import Vasprun
import os

def extract_last_5000_every_500(xml_path='vasprun.xml'):
    # 读取vasprun.xml
    vasprun = Vasprun(xml_path, parse_dos=False, parse_eigen=False)
    structures = vasprun.structures
    total_steps = len(structures)

    print(f"Total structures in vasprun.xml: {total_steps}")

    # 获取最后5000步，每隔500步取一
    start = max(0, total_steps - 5000)
    selected_indices = list(range(start, total_steps+1, 500))
    
    
    for idx in selected_indices:
        struct = structures[idx-1]
        step_num = idx
        folder = f"run/{step_num}"
        os.makedirs(folder, exist_ok=True)
        poscar_path = os.path.join(folder, "POSCAR")
        struct.to(fmt="poscar", filename=poscar_path)
        print(f"Saved step {step_num} to {poscar_path}")

if __name__ == "__main__":
    extract_last_5000_every_500()
