"""The indispensable input parameters for all functions are the path to the POSCAR file or the manual specification
of the elements of the structure, the lattice information and the position information. If the input parameters
contain only one structure, homogeneous stacking is performed. If heterogeneous stacking is required, the correct
information for both structure files must be provided. Layer spacing and vacuum space along the Z-direction can be
changed by entering the parameters d_inter and lv. """


# -----------------------N2/N2 bilayer construction--------------------------------
from pyhtstack2d.buildbilayer.stackBilayer import N2Bilayer

# Bilayer consisting of h-BN
N2Bilayer("Monolayer/1BN-POSCAR", d_inter=2.0).WritePOSCAR()

#  Homo-bilayer consisting of ‘p3m1’ monolayer
N2Bilayer("Monolayer/1GeSe-POSCAR", d_inter=2.0).WritePOSCAR()

#  Hetero-bilayer consisting of BP/GeSe
N2Bilayer("Monolayer/1BP-POSCAR", "Monolayer/1GeSe-POSCAR").WritePOSCAR()


# -----------------------TMDH/TMDH bilayer construction--------------------------------
from pyhtstack2d.buildbilayer.stackBilayer import TMDHBilayer, TMDHBilayerSquare

# Construction of a 2H-TMD bilayer
TMDHBilayer("Monolayer/1MoS2-POSCAR", "Monolayer/1WSe2-POSCAR").WritePOSCAR()

# Construction of a 1T-MH bilayer
TMDHBilayer("Monolayer/1MgI2-1.vasp", "Monolayer/1ZnI2-2.vasp").WritePOSCAR()

# Construction of a Square-MH bilayer
TMDHBilayerSquare("Monolayer/1CrI2-2.vasp", "Monolayer/1NiI2-2.vasp").WritePOSCAR()

# The handling of stacking sequence
TMDHBilayer("Monolayer/1MoSSe-POSCAR", "Monolayer/1STeW-POSCAR").WritePOSCAR()


# -----------------------MNXY/MNXY bilayer construction--------------------------------
from pyhtstack2d.buildbilayer.stackBilayer import MNXYBilayer

# Construction of a 2H-MNXY bilayer
MNXYBilayer("Monolayer/In1S2Ga1-POSCAR", "Monolayer/Se2Al1Ga1-POSCAR").WritePOSCAR()

# Construction of a 1T-MNXY bilayer
MNXYBilayer("Monolayer/2InSe-2.vasp", "Monolayer/2GaTe-2.vasp").WritePOSCAR()


# -----------------------N2/TMDH & N2/MNXY bilayer construction--------------------------
from pyhtstack2d.buildbilayer.stackBilayer import N2TMDHbilayer, N2MNXYBilayer

# Construction of a 2H-N2TMDH bilayer
N2TMDHbilayer("Monolayer/1BP-POSCAR", "Monolayer/1MoS2-POSCAR").WritePOSCAR()

# Construction of a 2H-N2MNXY bilayer
N2MNXYBilayer("Monolayer/1GeSe-POSCAR", "Monolayer/In1S2Ga1-POSCAR").WritePOSCAR()


# ============Listing 2: Using the Bilayer function to generate multilayer structures.==============
from pyhtstack2d.buildbilayer.stackBilayer import Bilayer

# Element, lattice and position of MoS2
elem1 = ['Mo', 'S', 'S']
la1 = [[3.184, 0.0, 0.0],
       [-1.592, 2.757, 0.0],
       [0.0, 0.0, 18.127]]
pos1 = [[0.0, 0.0, 0.50],
        [2/3, 1/3, 0.59],
        [2/3, 1/3, 0.41]]

# Element, lattice and position of WSe2
elem2 = ['W', 'Se', 'Se']
la2 = [[3.319, 0.0, 0.0],
       [-1.659, 2.874, 0.0],
       [0.0, 0.0, 18.358]]
pos2 = [[0.0, 0.0, 0.50],
        [2/3, 1/3, 0.59],
        [2/3, 1/3, 0.41]]

# Construct the AA stacking of MoS2/WSe2
Bilayer(elem1, elem2, la1=la1, la2=la2, position1=pos1, position2=pos2, lv=35).WritePOSCAR()

# Position of WSe2
pos2 = [[2/3, 1/3, 0.50],
        [0.0, 0.0, 0.59],
        [0.0, 0.0, 0.41]]

# Construct the AB stacking of MoS2/WSe2
Bilayer(elem1, elem2, la1=la1, la2=la2,position1=pos1, position2=pos2, lv=35, stackmode="AB").WritePOSCAR()

# The path of the POSCAR file of MoS2/WSe2
# S2MoSe2W_4.15%_3 divided into 3 parts by '_'
# S2MoSe2W is the formula, 4.15% is the lattice mismatch, and 3 is the number of atoms in the first layer
# AA: stacking pattern, cord1: first stacking sequence
MoS2WSe2_file = "BiPOSCAR_dir/S2MoSe2W_4.15%_3/AA/cord1/POSCAR"
# Construct the three-layer of MoS2/WSe2/MoS2
Bilayer(elem1, MoS2WSe2_file, la1=la1, position1=pos1).WritePOSCAR()
# =================================Listing 2 End.===================================================
