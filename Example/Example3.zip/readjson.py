import matplotlib.pyplot as plt

plt.rc('font', family='Arial')

import json

"""
Data and images covered in Section 4 illustrative examples in the article "PyHTStack2D: a Python package for high-throughput homo/hetero stacking of 2D materials".
biinfo-JSON/biinfo-(non)mag.json: The information of (non)magnetic bilayer materials, including the structure, energy and band structure.
biinfo-JSON/mixed.json: The information of mixed bilayer materials, including the structure, energy and band structure.
monoinfo-JSON/monoinfo.json: The information of monolayer materials, including the structure, energy and band structure.
bimag-JSON/bimagdict.json: The information of magnetic bilayer materials, including the various magnetic orders and energy.
bimag-JSON/bimagdictSum.json: Processing the file bimagdict.json, integrating information on the same chemical formula and analysing the magnetic ground state
biinfo-simple-nonmag-vaspkit.json: Processing the file biinfo-JSON/biinfo-nonmag.json, integrating information on the same chemical formula and analysing the type of band alignment.
"""
# ======================================================================================================================
# Plotting the data about the magnetic states and mixed states.
# ----------------- Get the number of (non)magnetic states and mixed states -----------------
# with open('./bimag-JSON/bimagdictSum.json', 'r') as f:
#     data = json.load(f)
#
# with open('biinfo-simple-nonmag-vaspkit.json', 'r') as f:
#     nomagdata = json.load(f)
#
# with open('biinfo-JSON/mixed.json', 'r') as f:
#     mixeddata = json.load(f)
#
# count1 = 0
# count2 = 0
# count3 = 0
# for key, value in data.items():
#     if key in mixeddata.keys():
#         count1 += 1
#         continue
#     if key in nomagdata.keys():
#         count2 += 1
#         # print(key, data[key]["maglist"], data[key]["magstatelistcorrect"], data[key]["stackmode"])
#     else:
#         count3 += 1
# print("Mixed: ", count1)
# print("(A)FM", count3)
#
#
# count = 0
# for key, value in nomagdata.items():
#     if key in mixeddata:
#         continue
#     count += 1
# print("All NM: ", count)
# ------------------------------------------------------------------------------------------

magstate = { "NM": 604, "Mixed": 29, "(A)FM": 284}
Mixedstate = {"FM/FM": {"homo": 2, "hetero": 3}, "NM/NM": {"homo": 3, "hetero": 14}, "NM/FM": {"hetero": 7}}

# Flatten Mixedstate for pie chart
flat_mixedstate = {f"{key}-{subkey}": value for key, subdict in Mixedstate.items() for subkey, value in subdict.items()}

# Function to add legend to pie chart
def add_legend_to_pie_chart(labels, loc="best"):
    # Create legend with labels and custom location
    plt.legend([f"{label}" for label in labels], loc=loc, fontsize=20)

# Plot pie chart for magstate with "Mixed" section exploded
explode_magstate = [0, 0.1, 0.0]  # Exploding the "Mixed" section
plt.figure(figsize=(6, 6))
wedges, texts, autotexts = plt.pie(magstate.values(), labels=None,
                                   autopct=lambda pct: f"{round(pct / 100 * sum(magstate.values()))}",
                                   colors=['#6baed6', '#fdcc8a', '#74c476'], startangle=90, explode=explode_magstate)

# Add legend with only the category names
add_legend_to_pie_chart(list(magstate.keys()), loc="best")

# Customize the numbers inside the pie slices
for autotext in autotexts:
    autotext.set_fontsize(20)
    autotext.set_fontweight('bold')

plt.title('Distribution of Magnetic States', fontsize=22,)
plt.tight_layout()
plt.savefig('magstate_pie.png', dpi=300)
plt.show()


# Plot pie chart for Mixedstate with "NM/NM-hetero" section exploded
explode_mixedstate = [0, 0, 0, 0.1, 0]  # Exploding the "NM/NM-hetero" section
plt.figure(figsize=(6, 6))
wedges, texts, autotexts = plt.pie(flat_mixedstate.values(), labels=None,
                                   autopct=lambda pct: f"{int(pct / 100 * sum(flat_mixedstate.values()))}",
                                   colors=['#6baed6', '#fdcc8a', '#74c476', '#fb6a4a', '#bcbddc', '#9e9ac8'],
                                   startangle=90, explode=explode_mixedstate)

# Add legend with only the category names and set it to the bottom right
def add_legend_to_pie_chart(labels, loc):
    # Force legend into two columns, placed outside the pie chart
    plt.legend([f"{label}" for label in labels], loc=loc, fontsize=16, bbox_to_anchor=(1, 1))

add_legend_to_pie_chart(list(flat_mixedstate.keys()), loc='best')

# Customize the numbers inside the pie slices
for autotext in autotexts:
    autotext.set_fontsize(18)
    autotext.set_fontweight('bold')

plt.title('Distribution of Mixed States', fontsize=18)
plt.tight_layout()
plt.savefig('mixedstate_pie.png', dpi=600)
plt.show()
# ======================================================================================================================


# ======================================================================================================================
# For mixed.json, we will plot the data as a scatter plot with different colors representing different materials.
import pandas as pd

with open('./biinfo-JSON/mixed.json', 'r') as f:
    data = json.load(f)

mag_eb = []
mag_dinter = []
for key, value in data.items():
    mags = value.get('mag', [])
    dinterlayer_values = value.get('dinterlayer', [])
    eb_values = value.get('Ef', [])
    # Set None values in mag to 0
    mags_fixed = [abs(mag) if mag is not None else 0 for mag in mags]
    for mag, eb in zip(mags_fixed, eb_values):
        mag_eb.append([mag, eb, key])
    for mag, dinterlayer in zip(mags_fixed, dinterlayer_values):
        mag_dinter.append([mag, dinterlayer, key])

# Create a DataFrame for the full data
df_mag_eb = pd.DataFrame(mag_eb, columns=["Mag", "Ef", "Material"])
df_mag_dinter = pd.DataFrame(mag_dinter, columns=["Mag", "Dinterlayer", "Material"])

# Assign numeric values to materials for plotting
df_mag_eb["Material_Index"] = df_mag_eb["Material"].factorize()[0]
df_mag_dinter["Material_Index"] = df_mag_dinter["Material"].factorize()[0]

# Create 2D plot with colors representing different materials, removing the material axis
fig, ax = plt.subplots(figsize=(6, 6))
# Use a scatter plot to display Ef (/Dinterlayer) vs Mag, with color representing different materials
ax.scatter(df_mag_eb['Ef'], df_mag_eb['Mag'], c=df_mag_eb['Material_Index'], cmap='tab20', marker='o')
ax.set_xlabel('Ef', fontsize=24)
ax.set_ylabel('Mag', fontsize=20)
from matplotlib.ticker import MultipleLocator
x_major_locator=MultipleLocator(0.5)
ax.xaxis.set_major_locator(x_major_locator)
# Enlarge tick labels
ax.tick_params(axis='both', which='major', labelsize=20)
# Set title
ax.set_title('Ef vs Mag (Colored by Material)', fontsize=22)
# Save the figure
plt.savefig('mixed_mag_eb.png', dpi=300)
# Display the plot
plt.show()
plt.close()
fig, ax = plt.subplots(figsize=(6, 6))
ax.scatter(df_mag_dinter['Dinterlayer'], df_mag_dinter['Mag'], c=df_mag_dinter['Material_Index'], cmap='tab20', marker='o')
ax.set_xlabel('Dinterlayer', fontsize=20)  # Change to Dinterlayer
ax.set_ylabel('Mag', fontsize=20)
ax.tick_params(axis='both', which='major', labelsize=20)
ax.set_title('Dinterlayer vs Mag (Colored by Material)', fontsize=20)
plt.tight_layout()
plt.savefig('mixed_mag_dinter.png', dpi=300)
plt.show()
# ======================================================================================================================


# ======================================================================================================================
# Get the number of deltabandgap < 0.1 for non-direct bandgap materials, where the deltabandgap is the difference between
# the direct and indirect bandgap.
with open('biinfo-simple-nonmag-vaspkit.json', 'r') as f:
    data = json.load(f)

direct_counts = 0
tot = 0
deltagap = []
for key, value in data.items():
    isdirect = value['direct']
    deltagaplist = value['deltabandgap']
    for i_, isd in enumerate(isdirect):
        tot += 1
        if not isd and deltagaplist[i_] < 0.1:
            deltagap.append(deltagaplist[i_])
        if isd:
            direct_counts += 1

print(f"Number of direct bandgap materials: {direct_counts}")
print(f"Total number of materials: {tot}")

import matplotlib.pyplot as plt

plt.hist(deltagap, bins=30, edgecolor='black')
plt.xlabel(f'$\Delta$-bandgap', fontsize=20)
plt.ylabel('Counts', fontsize=20)
plt.tick_params(axis='both', which='major', labelsize=18)
plt.title(f'$\Delta$-bandgap Distribution (Total: {len(deltagap)})', fontsize=20)
plt.tight_layout()
plt.savefig('deltabandgap.png', dpi=600)
plt.show()
# ======================================================================================================================


# ======================================================================================================================
# Load data from the provided JSON file, and extract the band alignment type and the bandgap type for each material.
with open('biinfo-simple-nonmag-vaspkit.json', 'r') as f:
    data = json.load(f)

# Initialize dictionaries for storing data
dir_dict = {0: {"gap": [], "Ef": []}, 1: {"gap": [], "Ef": []}, 2: {"gap": [], "Ef": []}, 3: {"gap": [], "Ef": []}, None: {"gap": [], "Ef": []}}
indir_dict = {0: {"gap": [], "Ef": []}, 1: {"gap": [], "Ef": []}, 2: {"gap": [], "Ef": []}, 3: {"gap": [], "Ef": []}, None: {"gap": [], "Ef": []}}

dir_counts = 0
indir_counts = 0
# Extract the required data
for key, value in data.items():
    isdirect = value['direct']
    bandgap = value['bandgap']
    Eflist = value['Ef']
    Dinterlayer = value['dinterlayer']
    bandalignment = value['bandalignment']
    for i_, isd in enumerate(isdirect):
        if isd and Eflist[i_] <= 0 and Dinterlayer[i_] > 2.0:
            dir_counts += 1
            dir_dict[bandalignment[i_]]["gap"].append(bandgap[i_])
            dir_dict[bandalignment[i_]]["Ef"].append(Eflist[i_])
        elif not isd and Eflist[i_] <= 0 and Dinterlayer[i_] > 2.0:
            indir_counts += 1
            indir_dict[bandalignment[i_]]["gap"].append(bandgap[i_])
            indir_dict[bandalignment[i_]]["Ef"].append(Eflist[i_])

print(f"Number of direct bandgap materials: {dir_counts}")
print(f"Number of indirect bandgap materials: {indir_counts}")

# Define new color scheme and markers for the updated request
# Define the updated colors and labels for the plot
colors = {0: 'gold', 1: 'red', 2: 'green', 3: 'blue', None: 'gray'}
labels = {0: 'Metal', 1: 'Type I', 2: 'Type II', 3: 'Type III', None: 'Unknown'}

# Create the scatter plot
plt.figure(figsize=(10, 6))

# Scatter plot for direct and indirect data
for key, color in colors.items():
    plt.scatter(dir_dict[key]["gap"], dir_dict[key]["Ef"], marker="x", color=color, alpha=0.7, s=100)
    plt.scatter(indir_dict[key]["gap"], indir_dict[key]["Ef"], marker="o", color=color, edgecolor='black', alpha=0.7)

# Add marker-based legend for direct and indirect bandgaps
plt.scatter([], [], marker="x", color='k', label="Direct")
plt.scatter([], [], marker="o", color='k', label="Indirect", edgecolor='black')

# Add color-based labels with solid blocks instead of x markers
for key, color in colors.items():
    plt.scatter([], [], marker='s', color=color, label=labels[key], s=100)  # Solid square blocks

# Add labels and legend
plt.tick_params(axis='both', which='major', labelsize=18)
plt.ylim(-0.8, 0.0)
plt.xlabel('Bandgap (eV)', fontsize=20)
plt.ylabel('Ef (eV)', fontsize=20)
plt.title('Ef vs Bandgap with Bandalignment', fontsize=20)
# plt.legend(loc='best', title='Markers: Direct/Indirect, Colors: Type', fontsize=16,  bbox_to_anchor=(1.05, 1), borderaxespad=0.)
plt.legend(loc='best', title='Markers: Direct/Indirect\nColors: Type', fontsize=18, title_fontsize=16)
plt.grid(True, color='gray', linestyle='--', linewidth=0.5)

# Show the plot
plt.tight_layout()
plt.savefig('Ef_vs_bandgap_bandalignment.png', dpi=600)
plt.show()
# ======================================================================================================================


# ======================================================================================================================
# Extract the type II materials with bandgap > 1.0 eV, and Z-scheme band alignment with bandgap between 0.1 and 0.3 eV.
with open('biinfo-simple-nonmag-vaspkit.json', 'r') as f:
    data = json.load(f)

for key, value in data.items():
    isdirect = value['direct']
    bandgap = value['bandgap']
    Eflist = value['Ef']
    Dinterlayer = value['dinterlayer']
    bandalignment = value['bandalignment']
    stackmode = value['stackmode']
    deltagaplist = value['deltabandgap']
    mistmatch = value['mismatchopt']
    for i_, isd in enumerate(isdirect):
        if 1.0 < bandgap[i_] and Eflist[i_] <= 0 and Dinterlayer[i_] > 2.0 and bandalignment[i_] == 2:
            print("Type II: ", key, stackmode[i_], bandgap[i_])
        if isd and 0.1 < bandgap[i_] < 0.3 and Eflist[i_] <= 0 and Dinterlayer[i_] > 2.0 and bandalignment[i_] == 2:
            print("Z-scheme: ", key, stackmode[i_], bandgap[i_])
# ======================================================================================================================


# ======================================================================================================================
# Load data from the provided JSON file, and extract the materials with mixed magnetic states.
with open('./bimag-JSON/bimagdictSum.json', 'r') as f:
    data = json.load(f)

with open('./bimag-JSON/bimagdict.json', 'r') as f:
    bimagdict = json.load(f)

dataE = {}
for mid in bimagdict.keys():
    midprefix = mid.split("_")[0]
    if midprefix not in dataE.keys():
        dataE[midprefix] = {"stackmode": [], "magstatelistcorrect": [], "maglist": [], "NFME": [], "AFM1E": []}
    dataE[midprefix]["stackmode"].extend(bimagdict[mid]["stackmode"])
    dataE[midprefix]["magstatelistcorrect"].extend(bimagdict[mid]["magstatelistcorrect"])
    dataE[midprefix]["maglist"].extend(bimagdict[mid]["maglist"])
    dataE[midprefix]["NFME"].extend(bimagdict[mid]["magE"]["NFM"])
    if len(bimagdict[mid]["magE"]["AFM1"]) != 0:
        dataE[midprefix]["AFM1E"].extend(bimagdict[mid]["magE"]["AFM1"])
    else:
        dataE[midprefix]["AFM1E"].extend([0.0] * len(bimagdict[mid]["magE"]["NFM"]))

with open('biinfo-JSON/mixed.json', 'r') as f:
    mixeddata = json.load(f)

allfm = 0
allafm = 0
mixmagstate = 0
for key, value in data.items():
    mixstatecorrect = value['mixstatecorrect']
    if key in mixeddata.keys():
        continue
    if not mixstatecorrect and value["magstatelistcorrect"][0] == "FM":
        allfm += 1
    if not mixstatecorrect and value["magstatelistcorrect"][0] == "AFM":
        allafm += 1
    if mixstatecorrect:
        mixmagstate += 1
        # print(key, value["maglist"])
        print(key, value["maglist"], '\n', value["magstatelistcorrect"], '\n', value['stackmode'], "\n", str("NFM: "),
              dataE[key]["NFME"], '\n', str("AFM: "), dataE[key]["AFM1E"], '\n')
print(f"Number of mixed state: {mixmagstate}")
print(f"Number of FM: {allfm}")
print(f"Number of AFM/FIM: {allafm}")

magnum ={"All FM": allfm,  "Mixed": mixmagstate, "All AFM/FIM": allafm,}

explode_magstate = [0, 0.1, 0]  # Exploding the "Mixed" section
plt.figure(figsize=(6, 6)) #colors=['slategray', 'royalblue', 'linen'],
wedges, texts, autotexts = plt.pie(magnum.values(), labels=None,
                                   autopct=lambda pct: f"{round(pct / 100 * sum(magnum.values()))}",colors=['#E6BA9D', 'slategray', '#D9DDBA'],
                                   startangle=90, explode=explode_magstate)
plt.legend(wedges, magnum.keys(), title="MGS", loc="center left", fontsize=20, title_fontsize=22)
plt.setp(autotexts, size=20, weight="bold")
plt.axis('equal')
plt.tight_layout()
plt.savefig('mixedmagstate.png', dpi=600)
plt.show()

with open('./bimag-JSON/bimagdict_pu.json', 'r') as f:
    bimagdict_pu = json.load(f)

fme = dataE["FeBr2VTeSe"]["NFME"]
afme = dataE["FeBr2VTeSe"]["AFM1E"]
de = [1000*(fme[i] - afme[i]) for i in range(len(fme))]

fmepu = bimagdict_pu["FeBr2VTeSe"]["magE"]["NFM"]
afmepu = bimagdict_pu["FeBr2VTeSe"]["magE"]["AFM1"]
depu = [1000*(fmepu[i] - afmepu[i]) for i in range(len(fmepu))]

fmehomo = dataE["ScBr2ScBr2"]["NFME"]
afmehomo = dataE["ScBr2ScBr2"]["AFM1E"]
dehomo = [1000*(fmehomo[i] - afmehomo[i]) for i in range(len(fmehomo))]

fmehomopu = bimagdict_pu["ScBr2ScBr2"]["magE"]["NFM"]
afmehomopu = bimagdict_pu["ScBr2ScBr2"]["magE"]["AFM1"]
dehomopu = [1000*(fmehomopu[i] - afmehomopu[i]) for i in range(len(fmehomopu))]

fig = plt.figure(figsize=(10, 6))
plt.plot(range(len(de)), de, marker='o', markersize=10, label='FeBr$_2$/VTeSe')
plt.plot(range(len(depu)), depu, marker='o', linestyle='dashed', markersize=10, label='FeBr$_2$/VTeSe (U=4 eV)')
plt.plot([0, 2, 6, 8, 10], dehomo, marker='s', markersize=10, label='ScBr$_2$/ScBr$_2$')
plt.plot([0, 2, 6, 8, 10], dehomopu, marker='s', linestyle='dashed',markersize=10, label='ScBr$_2$/ScBr$_2$ (U=4 eV)')
plt.xticks(range(len(fme)), ['AA', 'AA\'', 'AA2', 'AA2\'', 'AA2-2', 'AA2-2\'', 'AB', 'AB\'', 'AB2', 'AB2\'', 'AB3', 'AB3\''])

# plt.plot(range(len(dehomo)), dehomo, marker='s', markersize=10, label='ScBr$_2$/ScBr$_2$')
# plt.plot(range(len(dehomopu)), dehomopu, marker='s', linestyle='dashed',markersize=10, label='ScBr$_2$/ScBr$_2$ (U=4 eV)')
# plt.xticks(range(len(dehomo)), ['AA', 'AA2', 'AB', 'AB2', 'AB3'])
plt.xlabel('Stacking Mode', fontsize=22)
plt.ylabel('E$_{FM}$-E$_{AFM}$ (meV)', fontsize=22)
plt.legend(loc='best', fontsize=18)
plt.tick_params(axis='both', which='major', labelsize=18)
plt.axhline(0, color='gray', linestyle='dotted')
plt.tight_layout()
plt.savefig('magorder.png', dpi=600)
plt.show()
# ======================================================================================================================

