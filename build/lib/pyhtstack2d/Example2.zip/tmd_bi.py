# ---------------Get the uid of TMDs with specific criteria and save the csv file----------------
from pyhtstack2d.tools.queryDB import getuid


database = "../c2db.db"
criteria_p3m1 = 'natoms=3, dyn_stab=Yes, hform<0, gap>0, layergroup=p3m1'
criteria_p6m2 = 'natoms=3, dyn_stab=Yes, hform<0, gap>0, layergroup=p-6m2'
getuid(database, criteria_p3m1, save_csv_path='tmd_p3m1.csv', save_csv=True)
getuid(database, criteria_p6m2, save_csv_path='tmd_p6m2.csv', save_csv=True)


# ---------------Storage of the POSCAR of TMDs with specific UID and magstate split into two folders----------------
import pandas
from pyhtstack2d.tools.queryDB import getPOSACRfromuid

tmd_p3m1 = pandas.read_csv('tmd_p3m1.csv')
tmd_p6m2 = pandas.read_csv('tmd_p6m2.csv')

tmd_p3m1_uid_nm = []
tmd_p3m1_uid_fm = []
for i in range(len(tmd_p3m1)):
    if tmd_p3m1.iloc[i]['magstate'] == 'NM':
        tmd_p3m1_uid_nm.append(tmd_p3m1.iloc[i]['uid'])
    else:
        tmd_p3m1_uid_fm.append(tmd_p3m1.iloc[i]['uid'])

tmd_p6m2_uid_NM = []
tmd_p6m2_uid_FM = []
for i in range(len(tmd_p6m2)):
    if tmd_p6m2.iloc[i]['magstate'] == 'NM':
        tmd_p6m2_uid_NM.append(tmd_p6m2.iloc[i]['uid'])
    else:
        tmd_p6m2_uid_FM.append(tmd_p6m2.iloc[i]['uid'])

database = "../c2db.db"
getPOSACRfromuid(database, tmd_p3m1_uid_nm, overwrite=False, save_path='POSCAR_NM')
getPOSACRfromuid(database, tmd_p3m1_uid_fm, overwrite=False, save_path='POSCAR_FM')
getPOSACRfromuid(database, tmd_p6m2_uid_NM, overwrite=False, save_path='POSCAR_NM')
getPOSACRfromuid(database, tmd_p6m2_uid_FM, overwrite=False, save_path='POSCAR_FM')


# ---------------Check the TMDs in the POSCAR_Gd and POSCAR_Gind folders and only save the 2H TMDs----------------
import os
import shutil
from pyhtstack2d.buildbilayer.stackBilayer import Monolayer

for pos_dir in ['POSCAR_NM', 'POSCAR_FM']:
    rm_files = []
    for pos_file in os.listdir(pos_dir):
        momolayer = Monolayer(os.path.join(pos_dir, pos_file))
        a = momolayer.a
        b = momolayer.b
        try:
            momolayer.checkTMDH()
            tmd_type = momolayer.tmdtype
            if tmd_type != "2H" or abs(a-b) > 1e-4:
                rm_files.append(os.path.join(pos_dir, pos_file))
        except:
            rm_files.append(os.path.join(pos_dir, pos_file))

    for rm_file in rm_files:
        os.remove(rm_file)

    for pos_file in os.listdir(pos_dir):
        if "new_" in pos_file and not os.path.exists(os.path.join(pos_dir, pos_file.replace("new_", ""))):
            shutil.move(os.path.join(pos_dir, pos_file), os.path.join(pos_dir, pos_file.replace("new_", "")))


# ---------------Generate the bilayer structure of TMDs in the POSCAR_Gd and POSCAR_Gind folders----------------
from pyhtstack2d.buildbilayer.batchStackBilayer import GenBiLayer

GenBiLayer('POSCAR_NM', genmode="tmdh", la_mismatch=3.0, homo=True).batch_stack()
GenBiLayer('POSCAR_NM', 'POSCAR_FM',  genmode="tmdh", la_mismatch=3.0).batch_stack()
GenBiLayer('POSCAR_FM', genmode="tmdh", la_mismatch=3.0, homo=True).batch_stack()

# ---------------Generate the run shell script----------------
from pyhtstack2d.tools.genInput import GenRunDir, GenMultiSh

GenRunDir(genmode="vaspkit", posdir="BiPOSCAR_dir", workdir="BiPOSCAR_dir", multilevel=4, taskname="opt",
          incexis=True, kpexis=True).genInputfile()

incpath = ["INPUT_file/INCAR-opt", "INPUT_file/INCAR-scf", "INPUT_file/INCAR-band"]
kppath = ["INPUT_file/KPOINTS-opt", "INPUT_file/KPOINTS-scf", "INPUT_file/KPOINTS-band"]
GenMultiSh(tasklist=["opt", "scf", "band"], workdir="BiPOSCAR_dir", moduleload="vasp/5.4.4-intel2019", multilevel=4, opts=True,
           saveall=True, subset="slurm", incpath=incpath, kppath=kppath).genRunsh()
